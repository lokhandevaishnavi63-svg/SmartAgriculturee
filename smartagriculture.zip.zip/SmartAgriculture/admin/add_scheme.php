<?php

session_start();

if (!isset($_SESSION["admin"])) {

    header("Location: login.php");
    exit();

}

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "smart_agriculture"
);

if ($conn->connect_error) {

    die("Database connection failed!");

}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $scheme_name = $_POST["scheme_name"];
    $department = $_POST["department"];
    $description = $_POST["description"];
    $benefits = $_POST["benefits"];
    $last_date = $_POST["last_date"];
    $region = $_POST["region"];
    $application_procedure = $_POST["application_procedure"];
    $official_link = $_POST["official_link"];


    $stmt = $conn->prepare(
        "INSERT INTO schemes
        (scheme_name, department, description, benefits,
        last_date, region, application_procedure, official_link)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    );


    $stmt->bind_param(
        "ssssssss",
        $scheme_name,
        $department,
        $description,
        $benefits,
        $last_date,
        $region,
        $application_procedure,
        $official_link
    );


    if ($stmt->execute()) {

        $message = "Scheme added successfully!";

    } else {

        $message = "Error adding scheme.";

    }

}

?>

<!DOCTYPE html>

<html>

<head>

    <title>Add Scheme</title>

    <style>

        body {
            font-family: Arial;
            background: #e8f5e9;
        }

        .box {
            width: 650px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
        }

        h2 {
            color: #2e7d32;
            text-align: center;
        }

        input, textarea {
            width: 100%;
            padding: 11px;
            margin: 8px 0 15px;
            box-sizing: border-box;
        }

        textarea {
            height: 90px;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #2e7d32;
            color: white;
            border: none;
            cursor: pointer;
        }

        .message {
            text-align: center;
            color: green;
        }

    </style>

</head>

<body>

<div class="box">

    <h2>🌱 Add New Agriculture Scheme</h2>

    <?php if ($message != "") { ?>

        <p class="message">
            <?php echo $message; ?>
        </p>

    <?php } ?>


    <form method="POST">

        <label>Scheme Name</label>

        <input
            type="text"
            name="scheme_name"
            required
        >


        <label>Department</label>

        <input
            type="text"
            name="department"
            required
        >


        <label>Description</label>

        <textarea
            name="description"
            required
        ></textarea>


        <label>Benefits</label>

        <textarea
            name="benefits"
            required
        ></textarea>


        <label>Last Date</label>

        <input
            type="date"
            name="last_date"
        >


        <label>Region</label>

        <input
            type="text"
            name="region"
            placeholder="Konkan,Marathwada"
            required
        >


        <label>Application Procedure</label>

        <textarea
            name="application_procedure"
        ></textarea>


        <label>Official Website</label>

        <input
            type="url"
            name="official_link"
            placeholder="https://example.com"
        >


        <button type="submit">
            Add Scheme
        </button>

    </form>

    <br>

    <a href="dashboard.php">
        ← Back to Dashboard
    </a>

</div>

</body>

</html>