<?php

session_start();

if (!isset($_SESSION["admin"])) {

    header("Location: login.php");
    exit();

}

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "smart_agriculture"
);

if ($conn->connect_error) {

    die("Database connection failed!");

}

$result = $conn->query("SELECT * FROM schemes ORDER BY scheme_id DESC");

?>

<!DOCTYPE html>

<html>

<head>

    <title>Admin Dashboard</title>

    <style>

        body {
            font-family: Arial;
            background: #f4f8f4;
            margin: 0;
        }

        header {
            background: #2e7d32;
            color: white;
            padding: 20px 40px;

            display: flex;
            justify-content: space-between;
        }

        header a {
            color: white;
            text-decoration: none;
        }

        .container {
            width: 90%;
            margin: 30px auto;
        }

        h1 {
            color: #1b5e20;
        }

        .add-btn {
            display: inline-block;
            background: #2e7d32;
            color: white;
            padding: 12px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        th {
            background: #2e7d32;
            color: white;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .update {
            background: #1976d2;
            color: white;
            padding: 7px 12px;
            text-decoration: none;
            border-radius: 4px;
        }

        .delete {
            background: #d32f2f;
            color: white;
            padding: 7px 12px;
            text-decoration: none;
            border-radius: 4px;
        }

    </style>

</head>

<body>

<header>

    <strong>🌱 Smart Agriculture Admin</strong>

    <a href="logout.php">
        Logout
    </a>

</header>


<div class="container">

    <h1>Admin Dashboard</h1>

    <a class="add-btn" href="add_scheme.php">
        + Add New Scheme
    </a>


    <table>

        <tr>

            <th>ID</th>
            <th>Scheme Name</th>
            <th>Department</th>
            <th>Region</th>
            <th>Last Date</th>
            <th>Action</th>

        </tr>


        <?php while ($row = $result->fetch_assoc()) { ?>

        <tr>

            <td>
                <?php echo $row["scheme_id"]; ?>
            </td>

            <td>
                <?php echo htmlspecialchars($row["scheme_name"]); ?>
            </td>

            <td>
                <?php echo htmlspecialchars($row["department"]); ?>
            </td>

            <td>
                <?php echo htmlspecialchars($row["region"]); ?>
            </td>

            <td>
                <?php echo $row["last_date"]; ?>
            </td>

            <td>

                <a
                    class="update"
                    href="update_scheme.php?id=<?php echo $row["scheme_id"]; ?>"
                >
                    Update
                </a>

                <a
                    class="delete"
                    href="delete_scheme.php?id=<?php echo $row["scheme_id"]; ?>"
                    onclick="return confirm('Are you sure you want to delete this scheme?');"
                >
                    Delete
                </a>

            </td>

        </tr>

        <?php } ?>

    </table>

</div>

</body>

</html>