<?php

session_start();

if (!isset($_SESSION["admin"])) {

    header("Location: login.php");
    exit();

}

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "smart_agriculture"
);

if ($conn->connect_error) {

    die("Database connection failed!");

}

$id = intval($_GET["id"] ?? 0);

if ($id > 0) {

    $stmt = $conn->prepare(
        "DELETE FROM schemes WHERE scheme_id=?"
    );

    $stmt->bind_param("i", $id);

    $stmt->execute();

}

header("Location: dashboard.php");

exit();

?>