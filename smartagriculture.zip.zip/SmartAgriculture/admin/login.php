<?php
session_start();

$admin_username = "admin";
$admin_password = "admin123";

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST["username"];
    $password = $_POST["password"];

    if ($username === $admin_username && $password === $admin_password) {

        $_SESSION["admin"] = true;

        header("Location: dashboard.php");
        exit();

    } else {

        $error = "Invalid username or password!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>

    <title>Admin Login</title>

    <style>

        body {
            font-family: Arial;
            background: #e8f5e9;
        }

        .login-box {
            width: 350px;
            margin: 100px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            color: #2e7d32;
        }

        input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #2e7d32;
            color: white;
            border: none;
            cursor: pointer;
        }

        .error {
            color: red;
            text-align: center;
        }

    </style>

</head>

<body>

<div class="login-box">

    <h2>🌱 Admin Login</h2>

    <?php if ($error != "") { ?>

        <p class="error">
            <?php echo $error; ?>
        </p>

    <?php } ?>

    <form method="POST">

        <input
            type="text"
            name="username"
            placeholder="Admin Username"
            required
        >

        <input
            type="password"
            name="password"
            placeholder="Admin Password"
            required
        >

        <button type="submit">
            Login
        </button>

    </form>

</div>

</body>
</html>