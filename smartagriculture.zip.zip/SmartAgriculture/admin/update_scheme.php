<?php

session_start();

if (!isset($_SESSION["admin"])) {

    header("Location: login.php");
    exit();

}

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "smart_agriculture"
);

if ($conn->connect_error) {

    die("Database connection failed!");

}

$id = intval($_GET["id"] ?? 0);

if ($id <= 0) {

    die("Invalid scheme ID.");

}


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $scheme_name = $_POST["scheme_name"];
    $department = $_POST["department"];
    $description = $_POST["description"];
    $benefits = $_POST["benefits"];
    $last_date = $_POST["last_date"];
    $region = $_POST["region"];
    $application_procedure = $_POST["application_procedure"];
    $official_link = $_POST["official_link"];


    $stmt = $conn->prepare(
        "UPDATE schemes SET
        scheme_name=?,
        department=?,
        description=?,
        benefits=?,
        last_date=?,
        region=?,
        application_procedure=?,
        official_link=?
        WHERE scheme_id=?"
    );


    $stmt->bind_param(
        "ssssssssi",
        $scheme_name,
        $department,
        $description,
        $benefits,
        $last_date,
        $region,
        $application_procedure,
        $official_link,
        $id
    );


    $stmt->execute();


    header("Location: dashboard.php");

    exit();

}


$stmt = $conn->prepare(
    "SELECT * FROM schemes WHERE scheme_id=?"
);

$stmt->bind_param("i", $id);

$stmt->execute();

$result = $stmt->get_result();

$scheme = $result->fetch_assoc();


if (!$scheme) {

    die("Scheme not found.");

}

?>

<!DOCTYPE html>

<html>

<head>

    <title>Update Scheme</title>

    <style>

        body {
            font-family: Arial;
            background: #e8f5e9;
        }

        .box {
            width: 650px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
        }

        h2 {
            color: #2e7d32;
            text-align: center;
        }

        input, textarea {
            width: 100%;
            padding: 11px;
            margin: 8px 0 15px;
            box-sizing: border-box;
        }

        textarea {
            height: 90px;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #1976d2;
            color: white;
            border: none;
            cursor: pointer;
        }

    </style>

</head>

<body>

<div class="box">

    <h2>✏️ Update Agriculture Scheme</h2>

    <form method="POST">


        <label>Scheme Name</label>

        <input
            type="text"
            name="scheme_name"
            value="<?php echo htmlspecialchars($scheme["scheme_name"]); ?>"
            required
        >


        <label>Department</label>

        <input
            type="text"
            name="department"
            value="<?php echo htmlspecialchars($scheme["department"]); ?>"
            required
        >


        <label>Description</label>

        <textarea name="description"><?php
            echo htmlspecialchars($scheme["description"]);
        ?></textarea>


        <label>Benefits</label>

        <textarea name="benefits"><?php
            echo htmlspecialchars($scheme["benefits"]);
        ?></textarea>


        <label>Last Date</label>

        <input
            type="date"
            name="last_date"
            value="<?php echo $scheme["last_date"]; ?>"
        >


        <label>Region</label>

        <input
            type="text"
            name="region"
            value="<?php echo htmlspecialchars($scheme["region"]); ?>"
            required
        >


        <label>Application Procedure</label>

        <textarea name="application_procedure"><?php
            echo htmlspecialchars($scheme["application_procedure"]);
        ?></textarea>


        <label>Official Website</label>

        <input
            type="url"
            name="official_link"
            value="<?php echo htmlspecialchars($scheme["official_link"]); ?>"
        >


        <button type="submit">
            Update Scheme
        </button>

    </form>

    <br>

    <a href="dashboard.php">
        ← Back to Dashboard
    </a>

</div>

</body>

</html>